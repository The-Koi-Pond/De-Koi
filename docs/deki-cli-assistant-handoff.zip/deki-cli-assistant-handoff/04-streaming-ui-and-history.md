# Slice 4: Streaming UI And History

## Scope Lock
Do only this slice. Do not add new command families or mutation semantics. Use the contracts and runtime from prior slices. Stop after verification.

## Goal
Make Deki's shell feel like a live CLI-style assistant by streaming visible text, thinking/status, command start/update/end events, and pending approvals into the Deki UI. Persist enough trace history that finished messages show what Deki did without exposing hidden protocol frames.

## Required Context
- Parent handoff: `scratch/deki-cli-assistant-handoff/00-index.md`
- Prior dependencies: Slices 1-3.
- Marinara UI evidence:
  - `HomeProfessorMariChat.tsx` parses workspace events, maintains `workspaceTimeline`, renders tool events, and handles pending approvals.
  - `ProfessorMariWorkingWindow` gives a compact activity affordance.
  - Shared trace contract stores `text`, `thinking`, `tool`, and `status` trace items.
- Current Deki UI:
  - `src/features/shell/deki/components/DekiSurface.tsx` calls `runDekiEntry`, appends final assistant message, and renders `DekiActionCard`.
  - `src/shared/api/deki-api.ts` currently wraps final-response `deki_prompt`.

## Constraints
- Load `skills/de-koi-architecture-guard/SKILL.md` before editing.
- Owner lane: shared API runtime adapter and React Deki feature UI.
- Feature code must call `dekiApi`, not raw Tauri or raw remote fetch.
- Embedded Tauri should use `Channel` for streamed events.
- Remote runtime should use a dedicated SSE route or existing remote event helper pattern.
- Do not show hidden JSON command frames in the transcript.
- Keep UI dense and task-focused. Do not make a marketing-style surface.

## Target Files And Symbols
- `src/shared/api/deki-api.ts`: streamed prompt method and event normalization.
- `src/features/shell/deki/components/DekiSurface.tsx`: live timeline state, streaming assistant draft, approvals.
- `src-tauri/src/lib.rs`: Tauri command registration if adding channel command.
- `src-tauri/src/http_server.rs`: dedicated SSE route if remote streaming is implemented.
- `src/shared/api/remote-runtime.ts`: SSE helper usage or route allowlist as needed.
- Tests near `src/shared/api/deki-api.spec.ts` and possible component tests for Deki UI.

## Implementation Steps
1. Add a streamed prompt wrapper in `dekiApi.workspace.promptEvents` or similar:
   - Embedded: Tauri `Channel<DekiWorkspacePromptEvent>`.
   - Remote: SSE route using `streamRemoteJsonEvents`.
   - Keep the existing final `dekiApi.prompt` path until streaming is stable or adapt it internally.
2. Update `DekiSurface.send`:
   - Append user message as today.
   - Start a streaming assistant draft.
   - Append token chunks into visible assistant content.
   - Convert command events into timeline entries.
   - On done, persist the assistant message with content, action, and trace.
   - On error, show an error without saving hidden protocol text.
3. Render trace/timeline:
   - Command started/running/done/error.
   - Read/search/list/data command summaries.
   - Pending approval cards below the relevant assistant turn.
   - Applied/rejected state after approval resolution.
4. Add abort handling:
   - UI abort button or use existing send state controls.
   - `dekiApi.workspace.abort()` or stream cancellation.
   - Ensure stale streams cannot append into a newer message.
5. Persist trace history:
   - Extend message normalization in `deki-api.ts`.
   - Bound stored trace size/output length.
   - Finished tool events should render as done, not running.
6. Add focused tests:
   - Event normalization.
   - Trace persistence.
   - Approval card rendering or state transition if nearby test pattern is stable.

## Verification
- `pnpm typecheck`: proves TS/UI compile.
- Focused test command for `deki-api` and any Deki component tests added.
- Manual/native smoke if the claim includes actual streaming behavior in Tauri: send a Deki prompt that performs a read-only command and verify timeline events appear and no JSON protocol leaks.
- `pnpm check:architecture`: proves wrapper boundaries remain valid.

## Risks And Edge Cases
- Remote SSE requires auth/rate-limit/security consistency with existing hostable routes.
- Race conditions: stale stream events can corrupt the current message if a second prompt starts.
- Accessibility: approval cards need clear labels and disabled states.
- Persisted traces can get large; truncate tool outputs.

## Stop Condition
Stop after Deki streams live work and persists bounded trace history for existing command events. Do not add new command families or raw shell.

## Suggested Agent Prompt
Read `scratch/deki-cli-assistant-handoff/04-streaming-ui-and-history.md`. Implement only Slice 4. Load `skills/de-koi-architecture-guard/SKILL.md` first. Run the listed verification and report files changed, proof, and blockers.

