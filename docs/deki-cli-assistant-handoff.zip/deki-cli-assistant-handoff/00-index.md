# Deki CLI-Style Assistant Handoff Index

## Goal
Make Deki-senpai a true CLI-style local assistant, adapted from Professor Mari's Marinara Engine workspace work, without blindly porting package-era or legacy Rust shapes. The target behavior is a Deki workspace runtime that can inspect the De-Koi repository and app data through command-like tools, show live work/trace events in the UI, dry-run persistent changes, and require explicit user approval before applying them.

This is an implementation handoff, not an implementation. Feed one slice file to an implementation agent at a time.

## How To Use This Handoff
- Start from `main` in `C:\De-Koi`; verify it is still current before editing.
- Feed one numbered slice file to an agent at a time.
- Do not ask a weaker agent to implement the entire index.
- Each slice has its own scope lock, target files, proof, and stop condition.
- After a slice is complete and verified, update status before starting the next slice.

## Global Context
- Repository/workspace: `C:\De-Koi`
- De-Koi state when this handoff was created: `main` at `ef3ee2a5`, clean worktree.
- Source repo inspected: `C:\MarinaraEngine`; fetched `origin/main` at `8312ca92`. Local Marinara worktree had pre-existing generated-file edits, so source evidence was read from commits/remote refs only.
- User request: update De-Koi to latest `origin/main`, find Marinara commits related to making Professor Mari a true CLI-style assistant, and create a port plan for Deki.
- Important current Deki behavior:
  - `src-tauri/src/commands/storage/deki.rs` owns the privileged Deki prompt/runtime command.
  - `src/engine/deki/deki-entry.ts` owns frontend-facing Deki request/response/action contracts.
  - `src/shared/api/deki-api.ts` is the typed frontend runtime wrapper.
  - `src/features/shell/deki/components/DekiSurface.tsx` owns the React Deki shell UI.
  - `deki_prompt` is remote-capable through `src/shared/api/remote-runtime.ts` and `src-tauri/src/http_dispatch.rs`, but it currently returns a final response rather than live command events.
- Source evidence gathered:
  - `ca453846` adds Professor Mari workspace agent, CLI, routes, DB service, and shared contracts.
  - `06800d18` / `e8fecd54` are PR #2588 lineage: CLI availability and native/cross-platform shell/path fixes.
  - `1847ef81` cluster includes `f11e67ae`, `a340a7a3`, `9d45688a`, `b1bca02d`, `8c468eff`, `204717b4`: JSON command runtime, command loop hardening, mutation hardening, frame stripping, and removal of provider-native tool calls.
  - Older Rust/Tauri prior art: `73e3967b`, `1b1e7932`, `38b20626`, `35c70861`: trace events, live activity, workspace approvals, staged changes.

## Global Constraints
- Load `skills/de-koi-architecture-guard/SKILL.md` before code edits. Every slice touches architecture-sensitive imports, shared APIs, runtime adapters, Tauri/HTTP boundaries, or Rust capabilities.
- Product behavior belongs in `src/engine`.
- React UI belongs in `src/features`.
- Runtime wrappers belong in `src/shared/api`.
- Privileged and hostable runtime capabilities belong in `src-tauri`.
- Feature code must use typed shared API wrappers, not raw `invokeTauri` or raw `fetch`.
- Remote-capable behavior must use the explicit pipeline: typed shared API wrapper -> `tauri-client.ts` / `remote-runtime.ts` allowlist -> `/api/invoke` or dedicated `http_server.rs` route -> explicit `http_dispatch.rs` handler or focused Rust module.
- Do not add fake success, silent catches, broad fallbacks, or UI-only guards over broken contracts.
- Do not enable broad raw shell as the first implementation step. Build command families and approvals first.
- Chat, roleplay, and game mode owners must stay separate from Deki shell ownership.
- Do not stage or commit `scratch/` unless Xel explicitly asks.

## Slice Order
| Slice | File | Purpose | Dependencies | Proof |
| --- | --- | --- | --- | --- |
| 1 | `01-contracts-and-routing.md` | Add Deki workspace command/event/status contracts and remote route shape. | None | `pnpm typecheck`, `pnpm check:architecture` |
| 2 | `02-json-command-runtime.md` | Replace/augment provider-native tool dependency with a JSON command loop in Rust. | Slice 1 | `cargo check --manifest-path src-tauri/Cargo.toml`, targeted Rust tests |
| 3 | `03-data-cli-and-approvals.md` | Add Deki app-data CLI family with dry-run/apply approval flow. | Slices 1-2 | `cargo check --manifest-path src-tauri/Cargo.toml`, targeted approval/storage tests |
| 4 | `04-streaming-ui-and-history.md` | Stream trace/tool events to Deki UI and persist readable timeline history. | Slices 1-3 | `pnpm typecheck`, focused UI tests, manual/native smoke if needed |
| 5 | `05-hardening-docs-and-discovery.md` | Harden architecture, docs, discovery metadata, and final verification. | Slices 1-4 | `pnpm check:architecture`, `pnpm check:docs`, `cargo check --manifest-path src-tauri/Cargo.toml`, `pnpm typecheck` |

## Cross-Slice Risks
- Provider support: current Deki requires native tool calls. The Mari command-runtime source intentionally avoids native tool calls by forcing JSON command frames. The implementation must choose and consistently support one transition path.
- Remote hostability: SSE/channel behavior must work for embedded Tauri and hostable HTTP. Do not add embedded-only behavior to the shared API without a remote equivalent.
- Mutation safety: app-data writes need dry-run, validation, operation hash, pending approval, and explicit apply. Avoid direct raw storage writes from the model loop.
- Shell safety: raw shell is a later product/security decision, not a prerequisite for CLI-style app data commands.
- UI scope: Deki UI should show work and approvals without pulling chat/roleplay/game internals into the Deki feature owner.

## Open Questions
- Should Deki eventually get raw shell access, or should it remain limited to internal command families such as `deki data` and `deki code`?
- Should Deki code edits remain exact-match only, or should staged file changes be allowed after the approval pipeline exists?
- Should approvals persist across app restart, or is in-memory pending approval state acceptable for the first pass?

