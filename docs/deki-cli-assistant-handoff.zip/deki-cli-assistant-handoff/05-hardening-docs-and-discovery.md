# Slice 5: Hardening, Docs, And Discovery

## Scope Lock
Do only this slice after Slices 1-4 are complete. Do not add new major behavior unless it is needed to close a documented gap from previous slices. Stop after final verification.

## Goal
Harden the completed Deki CLI-style assistant path, update repo guidance/discovery metadata, and run the final checks that match the cross-boundary change.

## Required Context
- Parent handoff: `scratch/deki-cli-assistant-handoff/00-index.md`
- Prior dependencies: Slices 1-4 complete and verified.
- Repo rule: when adding, moving, or deleting a durable feature area, update the Deki-senpai Codebase Agent map in `AGENTS.md` so Deki's source map stays current.
- User-facing feature discovery lives in `src/features/shell/discovery`.

## Constraints
- Load `skills/de-koi-architecture-guard/SKILL.md` before editing.
- Owner lanes: docs/tooling, discovery, architecture validation.
- Do not self-name AI/tool/provider authorship in branches, commits, PR text, or docs.
- Do not over-document internals in user-facing copy.
- Do not mark success without running proof or naming gaps.

## Target Files And Symbols
- `AGENTS.md`: Deki map if new durable modules/routes were added.
- `src/features/shell/discovery/discovery-entries.json` and related registry tests if Deki discoverable behavior changed.
- `scripts/check-remote-runtime-dispatch.mjs` tests or snapshots if new remote commands/routes were added.
- `scripts/check-frontend-runtime-boundaries.mjs` if wrapper rules need explicit awareness of new Deki APIs.
- Any docs under `docs/` only if user/developer-facing behavior changed enough to need documentation.

## Implementation Steps
1. Audit architecture boundaries:
   - Engine contracts do not import React, stores, Tauri APIs, or shared API adapters.
   - Deki feature UI calls `dekiApi`, not raw Tauri or fetch.
   - New remote commands are allowlisted and explicitly dispatched.
   - Rust code is split if `deki.rs` became too broad.
2. Update Deki source map in `AGENTS.md`:
   - Add new `src-tauri/src/commands/storage/deki/*` modules if created.
   - Add streaming/approval route ownership if durable.
   - Add new shared API methods if useful for future agents.
3. Update discovery metadata only if user-visible Deki capabilities changed:
   - Avoid long explanatory copy.
   - Keep action routing through existing discovery action helpers.
4. Add or update guard tests:
   - Remote dispatch coverage for new command names/routes.
   - Frontend runtime boundary coverage if needed.
5. Run final verification:
   - Use focused checks first, then broader checks if this is PR-ready.

## Verification
- `pnpm check:architecture`: import, shared API, and remote dispatch rules.
- `pnpm check:docs`: docs/discovery/agent guidance checks.
- `pnpm typecheck`: TypeScript/UI/engine.
- `cargo check --manifest-path src-tauri/Cargo.toml`: Rust capabilities.
- Consider `pnpm check` only when preparing for PR/shipping or if prior slices touched enough areas to need the full baseline.

## Risks And Edge Cases
- Docs can drift from implementation if written too early. Verify final file paths before editing `AGENTS.md`.
- Discovery metadata checks may fail if actions or entries are incomplete.
- Full `pnpm check` may surface unrelated warning-only unused-code issues; report them accurately.

## Stop Condition
Stop after hardening/docs are updated and final verification is reported. Do not open a PR, push, or commit unless Xel explicitly asks.

## Suggested Agent Prompt
Read `scratch/deki-cli-assistant-handoff/05-hardening-docs-and-discovery.md`. Implement only Slice 5 after earlier slices are complete. Load `skills/de-koi-architecture-guard/SKILL.md` first. Run the listed verification and report files changed, proof, and any remaining risk.

