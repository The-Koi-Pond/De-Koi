# Slice 1: Contracts And Routing

## Scope Lock
Do only this slice. Do not implement the runtime loop, data mutation approvals, or UI timeline. Do not refactor unrelated Deki code. After completing the verification below, report results and stop unless Xel explicitly asks you to continue.

## Goal
Define the De-Koi-native Deki workspace contracts and routing shape needed for a CLI-style assistant. This slice should make later slices type-safe by adding command/event/status types and wrapper method stubs or no-op route scaffolding, without changing product behavior yet.

## Required Context
- Parent handoff: `scratch/deki-cli-assistant-handoff/00-index.md`
- Prior slice dependency: none.
- Source evidence: Marinara shared contract `packages/shared/src/types/professor-mari-workspace.ts` on `origin/main` defines tool names, trace items, status, pending approval, history, and prompt events.
- Current Deki contracts live in `src/engine/deki/deki-entry.ts`.
- Current Deki API wrapper lives in `src/shared/api/deki-api.ts`.
- Current remote command allowlist includes `deki_prompt` in `src/shared/api/remote-runtime.ts`; HTTP dispatch handles it in `src-tauri/src/http_dispatch.rs`.

## Constraints
- Load `skills/de-koi-architecture-guard/SKILL.md` before editing.
- Owner lane: TypeScript engine contracts, shared API runtime adapter, embedded/hostable runtime routing.
- Keep React out of `src/engine`.
- Keep raw `invokeTauri` inside `src/shared/api/deki-api.ts`; feature code must not call it directly.
- Remote-capable commands must be explicit in `remote-runtime.ts` and `http_dispatch.rs`.
- Do not add raw shell access in this slice.

## Target Files And Symbols
- `src/engine/deki/deki-entry.ts`: add Deki workspace tool/event/status/action result types.
- `src/shared/api/deki-api.ts`: expose typed methods for future workspace prompt/status/abort/approval calls. Stub only if the Rust route does not exist yet.
- `src/shared/api/remote-runtime.ts`: add any new remote command names that use `/api/invoke`.
- `src-tauri/src/http_dispatch.rs`: add explicit dispatch stubs for new invoke-style commands only if the shared API calls them in this slice.
- `src-tauri/src/commands/storage/deki.rs`: add request/response structs or lightweight command handlers only as needed to keep compilation/typechecking aligned.

## Implementation Steps
1. Add TypeScript contract types under `src/engine/deki/deki-entry.ts`:
   - `DekiWorkspaceToolName`: start with internal names only, likely `read`, `grep`, `find`, `ls`, `deki_data`, `deki_code`.
   - `DekiWorkspaceTraceItem`: text/thinking/status/tool.
   - `DekiWorkspacePromptEvent`: token/thinking/status/tool_start/tool_update/tool_end/approval_pending/metadata/done/error.
   - `DekiWorkspaceStatus`, `DekiWorkspacePendingApproval`, `DekiWorkspaceHistoryEntry`.
2. Extend `DekiMessage` only if needed to carry optional workspace trace/history. Keep existing `action` and `actionApplication` intact.
3. Add typed wrapper method shapes in `dekiApi.workspace`, such as:
   - `status(connectionId?: string | null)`
   - `abort()`
   - `approve(id: string)`
   - `reject(id: string)`
   - Do not wire streaming yet unless implementing slice 4 in the same PR is explicitly requested.
4. If adding new invoke command names, update `remote-runtime.ts` and `http_dispatch.rs` with explicit names and handlers that return a clear `not implemented` error or current status without side effects.
5. Add narrow TypeScript tests if nearby tests make this cheap, especially normalizers for new optional message trace fields.

## Verification
- `pnpm typecheck`: proves new TypeScript contracts and wrappers compile.
- `pnpm check:architecture`: proves shared API and remote dispatch boundaries are still valid.

## Risks And Edge Cases
- Too much behavior in contracts: keep this slice structural and typed, not functional.
- Over-broad command names: start with Deki-specific/internal command names and leave raw `bash` out.
- Remote mismatch: every command reachable through remote runtime must be allowlisted and dispatched explicitly.

## Stop Condition
Stop after contracts/routing compile and architecture checks pass. Do not implement the runtime command loop or UI timeline in this slice.

## Suggested Agent Prompt
Read `scratch/deki-cli-assistant-handoff/01-contracts-and-routing.md`. Implement only Slice 1. Load `skills/de-koi-architecture-guard/SKILL.md` first. Run `pnpm typecheck` and `pnpm check:architecture`, then report files changed, proof, and blockers.

