# Slice 2: JSON Command Runtime

## Scope Lock
Do only this slice. Do not add durable app-data mutation approval, UI timeline rendering, or raw shell. After verification, report results and stop unless Xel explicitly asks you to continue.

## Goal
Adapt Professor Mari's JSON command protocol to Deki's Rust runtime so Deki can operate like a CLI-style assistant without requiring provider-native tool calls for every step. The model should emit a hidden JSON action frame with visible text in `say`, a list of commands to execute, and a `stop` flag.

## Required Context
- Parent handoff: `scratch/deki-cli-assistant-handoff/00-index.md`
- Prior dependency: Slice 1 contracts exist.
- Marinara source evidence:
  - `f11e67ae`: refactors Professor Mari workspace to native command runtime.
  - `b1bca02d`: removes native tool calls from Professor Mari workspace.
  - `8c468eff`: hardens command frame stripping.
  - `204717b4`: repairs JSON command protocol history.
- Current De-Koi runtime:
  - `src-tauri/src/commands/storage/deki.rs` currently uses `autoagents`, native tools, and `ensure_connection_supports_native_tools`.
  - The system prompt currently tells Deki to use tool calls and `<deki_action>` blocks.

## Constraints
- Load `skills/de-koi-architecture-guard/SKILL.md` before editing.
- Owner lane: Rust privileged runtime and TypeScript engine contract compatibility.
- Keep Deki's creative-library action-card contract working. Do not break existing `<deki_action>` approval cards.
- Do not add raw shell access here.
- Do not remove native-tool support unless the JSON loop fully replaces every current required capability.
- Keep code file reads restricted to De-Koi repo paths and deny secrets/private data as current Deki does.

## Target Files And Symbols
- `src-tauri/src/commands/storage/deki.rs`: likely split into submodules if the file grows too broad.
- Potential new Rust modules under `src-tauri/src/commands/storage/deki/`: `protocol.rs`, `workspace_commands.rs`, `prompt.rs`, `types.rs`.
- `src/engine/deki/deki-entry.ts`: adjust response/action contract only if needed.
- Existing tests inside `deki.rs`: extend parser/protocol tests.

## Implementation Steps
1. Add a Deki workspace command protocol prompt equivalent to Marinara's JSON contract:
   - Model must return exactly one JSON object for command-loop turns.
   - Fields: `say`, `commands`, `stop`.
   - Supported command list for this slice: read-only repo/app helpers only, such as `read`, `grep`, `find`, `ls`, `read_deki_library`, `search_deki_code`, `read_deki_code_file`.
2. Add robust JSON payload extraction:
   - Accept raw JSON object.
   - Optionally tolerate fenced JSON only if it is stripped from visible output.
   - Reject or repair multiple frames deterministically.
   - Visible text must come from `say`/`message`/`final`, not protocol leakage.
3. Implement a bounded command loop:
   - Maximum rounds, e.g. 8-12.
   - Read-only command batching can run in parallel only if it is simple and deterministic.
   - Command results feed back as hidden evidence to the next model turn.
   - Preserve conversation history with compact command-result summaries.
4. Route current Deki read tools through command execution functions:
   - `search_deki_code`
   - `read_deki_code_file`
   - `read_deki_library`
   - Optional `ls/find/grep` wrappers, repo-root constrained.
5. Keep existing creative-library action parsing:
   - A final visible answer can still include one `<deki_action>{...}</deki_action>` block for app-visible approval cards.
   - Command protocol JSON should not leak into the saved assistant message.
6. Add Rust unit tests for:
   - Valid JSON command frame parsing.
   - Fenced JSON stripping.
   - Protocol leakage removal.
   - Max-round fallback.
   - Existing `<deki_action>` extraction still works.

## Verification
- `cargo check --manifest-path src-tauri/Cargo.toml`: proves Rust compiles.
- Targeted Rust tests for `deki` parser/protocol if available through `cargo test --manifest-path src-tauri/Cargo.toml <test-name>`.
- `pnpm typecheck` if TypeScript contracts changed.

## Risks And Edge Cases
- Provider behavior varies. Some providers may wrap JSON in prose; tolerate common safe cases but do not silently accept ambiguous or multiple command frames.
- Existing Deki prompt/action behavior is user-visible; preserve it.
- Command output can explode context. Add output limits and truncation before feeding results back to the model.

## Stop Condition
Stop after the JSON command loop supports read-only Deki workspace commands and existing Deki action cards still parse. Do not implement app-data apply approvals or UI event streaming in this slice.

## Suggested Agent Prompt
Read `scratch/deki-cli-assistant-handoff/02-json-command-runtime.md`. Implement only Slice 2. Load `skills/de-koi-architecture-guard/SKILL.md` first. Run the listed Rust and TypeScript checks, then report files changed, proof, and blockers.

