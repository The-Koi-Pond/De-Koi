# Slice 3: Data CLI And Approvals

## Scope Lock
Do only this slice. Do not add raw shell or broad file editing. Do not redesign the Deki UI beyond whatever minimal API compatibility is required. Stop after verification.

## Goal
Add a Deki-native app-data command family with dry-run and approval semantics. This is the core of making Deki "CLI-style" for saved De-Koi data without letting the model directly mutate storage.

## Required Context
- Parent handoff: `scratch/deki-cli-assistant-handoff/00-index.md`
- Prior dependencies: Slice 1 contracts and Slice 2 command loop exist.
- Marinara source evidence:
  - `packages/server/src/bin/mari.ts` forwards CLI args to a privileged server route.
  - `packages/server/src/services/mari-db/mari-db.service.ts` implements dry-run, validation, pending approvals, operation hash, history, and journal.
  - `packages/server/src/routes/professor-mari-workspace.routes.ts` exposes `/approvals/:id/approve`, `/reject`, `/history`, and `/db/command`.
- Current De-Koi app-data writes happen through storage APIs and Rust `FileStorage`.

## Constraints
- Load `skills/de-koi-architecture-guard/SKILL.md` before editing.
- Owner lane: Rust capability, shared API wrapper, engine contracts.
- Persistent writes must require explicit user approval.
- Dry-run is default for mutation commands.
- Do not allow model-produced raw `storage.update` equivalents to apply directly.
- Prefer existing De-Koi storage normalization helpers where available.
- Do not add raw shell.

## Target Files And Symbols
- `src-tauri/src/commands/storage/deki.rs` or split modules under `src-tauri/src/commands/storage/deki/`.
- `src-tauri/src/http_dispatch.rs` for explicit remote approval/status commands if needed.
- `src/shared/api/deki-api.ts` for typed approval/status methods.
- `src/engine/deki/deki-entry.ts` for approval/history result types.
- Storage helpers in `src-tauri/src/commands/storage/shared.rs` if normalization is needed.

## Implementation Steps
1. Define a Deki command family such as `deki_data` rather than copying `mari db` names:
   - Read: `status`, `collections`, `list`, `get`, `search`, `schema` if schema data exists.
   - Mutate dry-run: `insert`, `patch`, `replace`, `delete`.
   - Apply: only through approval resolution, not directly from the model loop.
2. Implement command parsing as structured JSON arguments, not shell words, for the model loop:
   - Example command frame: `{"name":"deki_data","arguments":{"action":"patch","collection":"personas","id":"...","patch":{...},"reason":"..."}}`
   - Keep shell-like labels for UI presentation later, but avoid command-line quoting bugs in Rust.
3. Implement dry-run planning:
   - Compute before/after row changes.
   - Validate collection and id.
   - Normalize create/update payloads through existing storage shared helpers where possible.
   - Return a compact diff summary and operation hash.
4. Implement pending approvals:
   - Pending approval id.
   - Session id.
   - Command summary.
   - Operation hash.
   - Affected collection counts.
   - Preview rows with truncation.
   - Expiration policy.
5. Implement approve/reject commands:
   - Reject removes pending approval and records history.
   - Approve recomputes the current plan and blocks if state changed.
   - Apply through `FileStorage` APIs only after approval.
   - Flush or rely on existing storage persistence semantics according to current storage owner patterns.
6. Implement history/journal:
   - Keep a compact history row list in app settings or a dedicated collection only if repo patterns support it.
   - If adding journal files, store under De-Koi app data, not repo scratch.
7. Add tests for:
   - Dry-run does not write.
   - Approval apply writes exactly planned changes.
   - State-change hash mismatch blocks apply.
   - Invalid collection/action is rejected.
   - Delete previews are bounded.

## Verification
- `cargo check --manifest-path src-tauri/Cargo.toml`: proves Rust compiles.
- Targeted Rust tests for Deki data command planning/approval.
- `pnpm typecheck` if API contracts changed.
- `pnpm check:architecture` if remote/shared wrapper routing changed.

## Risks And Edge Cases
- De-Koi storage collection names differ from Marinara table names. Use current collection names from code, not source commits.
- Mutating chats/messages/memories may be high risk. Consider excluding private transcripts and messages in the first pass.
- Approval persistence across restart is an open question. If in-memory first, document that clearly.

## Stop Condition
Stop after Deki has dry-run data commands and approve/reject apply flow covered by tests. Do not implement raw shell or full UI polish in this slice.

## Suggested Agent Prompt
Read `scratch/deki-cli-assistant-handoff/03-data-cli-and-approvals.md`. Implement only Slice 3. Load `skills/de-koi-architecture-guard/SKILL.md` first. Run the listed checks and tests, then report files changed, proof, and blockers.

